package com.simicart.plugins.instantcontact.common;

public class ContactUsConstant {

	public static String WEB_SITE = "website";
	public static String STYLE = "style";
	public static String ACTIVECOLOR = "activecolor";
	public static String PHONE = "phone";
	public static String EMAIL = "email";
	public static String MESSAGE = "message";
}
