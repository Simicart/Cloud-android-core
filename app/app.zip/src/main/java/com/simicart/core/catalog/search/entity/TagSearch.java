package com.simicart.core.catalog.search.entity;


public class TagSearch {
	
	public static String TAG_LISTVIEW = "listview";
	public static String TAG_GRIDVIEW = "gridview";
//	public static String TYPE_SEARCH_QUERY = "query";
//	public static String TYPE_SEARCH_CATEGORYID ="categoryid";
	
}
