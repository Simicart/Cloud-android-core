package com.simicart.core.slidemenu.block;

import java.util.ArrayList;

import com.simicart.core.slidemenu.delegate.SlideMenuDelegate;
import com.simicart.core.slidemenu.entity.ItemNavigation;

public class SlideMenuBlock implements SlideMenuDelegate {

	@Override
	public void onSelectedItem(int position) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setAdapter(ArrayList<ItemNavigation> items) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setUpdateSignIn(String name) {
		// TODO Auto-generated method stub

	}

}
