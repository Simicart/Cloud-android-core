package com.simicart.core.banner.controller;

import org.json.JSONObject;

import com.simicart.core.banner.delegate.BannerDelegate;
import com.simicart.core.banner.model.BannerModel;
import com.simicart.core.base.controller.SimiController;
import com.simicart.core.base.delegate.ModelDelegate;

public class BannerController extends SimiController {
	protected BannerDelegate mDelegate;

	public BannerController(BannerDelegate delegate) {
		mDelegate = delegate;
	}

	public void setDelegate(BannerDelegate delegate) {
		mDelegate = delegate;
	}

	@Override
	public void onStart() {
		// mDelegate.showLoading();
		ModelDelegate delegate = new ModelDelegate() {

			@Override
			public void callBack(String message, boolean isSuccess) {
				// mDelegate.dismissLoading();
				if (isSuccess) {
					mDelegate.updateView(mModel.getCollection());
					JSONObject object = mModel.getCollection().getJSON();
					System.out.println(object);
				}

			}
		};
		mModel = new BannerModel();
		mModel.setDelegate(delegate);
		mModel.addParam("limit", "10");
		mModel.request();
	}

	@Override
	public void onResume() {
		mDelegate.updateView(mModel.getCollection());
	}

}
