package com.simicart.core.style;

import android.content.Context;
import android.support.v4.widget.DrawerLayout;

public class SimiDrawerLayout extends DrawerLayout {

	private static final int MIN_DRAWER_MARGIN = 0; // dp

	public SimiDrawerLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

}
