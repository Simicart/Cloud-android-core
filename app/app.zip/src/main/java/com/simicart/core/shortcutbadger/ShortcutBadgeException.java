package com.simicart.core.shortcutbadger;

/**
 * Created with IntelliJ IDEA.
 * User: leolin
 * Date: 2013/11/14
 * Time:
 * To change this template use File | Settings | File Templates.
 */
public class ShortcutBadgeException extends Exception {
    public ShortcutBadgeException(String message) {
        super(message);
    }
}
