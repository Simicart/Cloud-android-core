package com.simicart.core.banner.block;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.ViewFlipper;

import com.simicart.core.banner.controller.BannerAnimation;
import com.simicart.core.banner.delegate.BannerDelegate;
import com.simicart.core.banner.entity.BannerEntity;
import com.simicart.core.base.block.SimiBlock;
import com.simicart.core.base.model.collection.SimiCollection;
import com.simicart.core.base.model.entity.SimiEntity;
import com.simicart.core.common.DrawableManager;
import com.simicart.core.config.Constants;
import com.simicart.core.config.DataLocal;
import com.simicart.core.config.Rconfig;

public class BannerBlock extends SimiBlock implements BannerDelegate {

	protected ViewFlipper mBannerFlipper;
	protected View mView;
	protected Context mContext;

	public BannerBlock(View view, Context context) {
		this.mView = view;
		this.mContext = context;
	}

	public void setContext(Context context) {
		mContext = context;
	}

	public void setRootView(View rootView) {
		mView = rootView;
	}

	@Override
	public void initView() {
		mBannerFlipper = (ViewFlipper) mView.findViewById(Rconfig.getInstance()
				.id("banner_slider"));
	}

	@Override
	public void drawView(SimiCollection collection) {
		ArrayList<SimiEntity> listBanner = collection.getCollection();
		if (listBanner == null || listBanner.size() == 0) {
			showBannersFake();
		} else {
			showBanners(listBanner);
		}
	}

	private void showBannersFake() {
		for (int i = 0; i < 3; i++) {
			LayoutInflater inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			LinearLayout bannerView = (LinearLayout) inflater.inflate(Rconfig
					.getInstance().layout("core_banner_home"), null, false);
			ImageView bannerImageView = (ImageView) bannerView
					.findViewById(Rconfig.getInstance().id("image_banner_home"));
			if (DataLocal.isTablet) {
				bannerImageView.setScaleType(ScaleType.CENTER_CROP);
			}
			bannerImageView.setImageResource(Rconfig.getInstance().drawable(
					"fake_banner"));
			bannerImageView.setScaleType(ScaleType.FIT_XY);
			mBannerFlipper.addView(bannerView);
		}
	}

	private void showBanners(ArrayList<SimiEntity> listBanner) {
		if (listBanner.size() == 1) {
			BannerAnimation bannerAnimation = new BannerAnimation(mView,
					mBannerFlipper, false);
			bannerAnimation.isAnimation(false);
			LayoutInflater inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			LinearLayout bannerView = (LinearLayout) inflater.inflate(Rconfig
					.getInstance().layout("core_banner_home"), null, false);
			ImageView bannerImageView = (ImageView) bannerView
					.findViewById(Rconfig.getInstance().id("image_banner_home"));
			SimiEntity entity = listBanner.get(0);

			if (entity.getData(Constants.IMAGE_PATH) != null) {
				DrawableManager.fetchDrawableOnThread(
						entity.getData(Constants.IMAGE_PATH), bannerImageView);
			}
			BannerEntity bannerEntity = new BannerEntity();
			bannerEntity.setUrl(entity.getData(Constants.URL));
			bannerEntity.setImage(entity.getData(Constants.IMAGE_PATH));
			bannerEntity.setType(entity.getData("type"));
			bannerEntity.setCategoryName(entity.getData("categoryName"));
			bannerEntity.setCategoryId(entity.getData("categoryID"));
			bannerEntity.setHasChild(entity.getData(Constants.HAS_CHILD));
			bannerEntity.setProductId(entity.getData("productID"));
			mBannerFlipper.addView(bannerView);
			bannerAnimation.onTouchEvent(bannerEntity, bannerView);
		} else {
			BannerAnimation bannerAnimation = new BannerAnimation(mView,
					mBannerFlipper);
			for (int i = 0; i < listBanner.size(); i++) {

				SimiEntity entity = listBanner.get(i);
				LayoutInflater inflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				LinearLayout bannerView = (LinearLayout) inflater.inflate(
						Rconfig.getInstance().layout("core_banner_home"), null,
						false);
				ImageView bannerImageView = (ImageView) bannerView
						.findViewById(Rconfig.getInstance().id(
								"image_banner_home"));
				if (DataLocal.isTablet) {
					bannerImageView.setScaleType(ScaleType.CENTER_CROP);
				}
				if (entity.getData(Constants.IMAGE_PATH) != null) {
					DrawableManager.fetchDrawableOnThread(
							entity.getData(Constants.IMAGE_PATH),
							bannerImageView);

				}
				BannerEntity bannerEntity = new BannerEntity();
				bannerEntity.setUrl(entity.getData(Constants.URL));
				bannerEntity.setImage(listBanner.get(i).getData(
						Constants.IMAGE_PATH));
				bannerEntity.setType(entity.getData("type"));
				bannerEntity.setCategoryName(entity.getData("categoryName"));
				bannerEntity.setCategoryId(entity.getData("categoryID"));
				bannerEntity.setHasChild(entity.getData(Constants.HAS_CHILD));
				bannerEntity.setProductId(entity.getData("productID"));
				mBannerFlipper.addView(bannerView);
				bannerAnimation.onTouchEvent(bannerEntity, bannerView);
			}
		}
	}

}
