package com.simicart.core.common.options.delegate;

import java.util.ArrayList;

public interface DependOptionDelegate {

	public void onReceiveDependOption(ArrayList<String> dependence_options);
}
