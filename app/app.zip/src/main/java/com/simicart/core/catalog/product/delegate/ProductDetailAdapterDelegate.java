package com.simicart.core.catalog.product.delegate;

public interface ProductDetailAdapterDelegate {

	public String getCurrentID();
}
