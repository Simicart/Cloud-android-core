package com.simicart.core.catalog.filter.delegate;

public interface DetailFilterDelegate {

	
	public void dismissDiaglog();
	
}
