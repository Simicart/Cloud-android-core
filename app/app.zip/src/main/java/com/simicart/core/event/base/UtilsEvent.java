package com.simicart.core.event.base;

import java.util.ArrayList;

public class UtilsEvent {
	public static ArrayList<ItemMaster> itemsList = new ArrayList<ItemMaster>();

}
