package com.simicart.core.slidemenu.delegate;

public interface CloseSlideMenuDelegate {
	public void closeSlideMenu();
}
