package com.simicart.core.base.network.request.multi;

public interface SimiNetwork {

	public SimiNetworkResponse performRequest(SimiRequest request);
}
